import requests
import os
import time
from collections.abc import Generator
from typing import Any

from dify_plugin import Tool, ToolInvokeMessage, ToolErrorMessage

class HeygenDifyPluginTool(Tool):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.video_count = 0
        self.default_template_id = "f5816b4a65764e068f0ada4f7b15162e"

    def _invoke(self, tool_parameters: dict[str, Any]) -> Generator[ToolInvokeMessage, None, None]:
        """
        Invoke the tool.
        """
        api_key = self.credentials.get("heygen_api_key")
        if not api_key:
            yield ToolErrorMessage(err="heygen_api_key is not configured")
            return

        audio_url = tool_parameters.get("audio_url")
        if not audio_url:
            yield ToolErrorMessage(err="audio_url is required")
            return

        lang = tool_parameters.get("lang", "zh")
        chapter = tool_parameters.get("chapter", 1)
        title = tool_parameters.get("title", "New Video")
        template_id = tool_parameters.get("template_id", self.default_template_id)

        variables = {
            "audio": {
                "name": "audio",
                "type": "audio",
                "properties": {
                    "url": audio_url
                }
            }
        }

        # 1. Generate video
        url = f"https://api.heygen.com/v2/template/{template_id}/generate"
        headers = {
            "X-Api-Key": api_key,
            "Content-Type": "application/json",
        }
        payload = {
            "caption": False,
            "title": title,
            "variables": variables
        }

        try:
            yield self.create_text_message("Generating video from HeyGen...")
            resp = requests.post(url, headers=headers, json=payload, timeout=60)
            resp.raise_for_status()
            result = resp.json()
            video_id = result.get("video_id")
            if not video_id:
                yield ToolErrorMessage(err="HeyGen API did not return video_id")
                return

            # 2. Poll for video status and download link
            yield self.create_text_message(f"Polling for video status (ID: {video_id})...")
            status_url = f"https://api.heygen.com/v1/video_status.get?video_id={video_id}"
            video_url = None
            for i in range(30):  # Poll for 150 seconds max
                status_resp = requests.get(status_url, headers={"X-Api-Key": api_key}, timeout=10)
                status_resp.raise_for_status()
                status_data = status_resp.json()
                if status_data.get("status") == "completed":
                    video_url = status_data.get("video_url")
                    yield self.create_text_message("Video generation completed.")
                    break
                elif status_data.get("status") == "failed":
                    yield ToolErrorMessage(err=f"Video generation failed. Reason: {status_data.get('error', 'Unknown error')}")
                    return
                
                yield self.create_text_message(f"Video status is '{status_data.get('status', 'unknown')}'. Waiting... ({i+1}/30)")
                time.sleep(5)

            if not video_url:
                yield ToolErrorMessage(err="Video generation timed out after 150 seconds.")
                return

            # 3. Download video with specified naming convention
            yield self.create_text_message(f"Downloading video from {video_url}...")
            self.video_count += 1
            video_num = f"{self.video_count:03d}"
            video_filename = f"{lang}_ai_{chapter}_v{video_num}_a.mp4"
            
            # Note: Dify plugins run in a sandboxed environment.
            # Saving files locally might not be accessible from the outside.
            # Returning the video URL is the most reliable method.
            # If local saving is needed, a persistent volume would be required.
            
            # For now, we just return the final URL and filename.
            # The download logic is commented out as it might not be useful in the Dify cloud environment.
            """
            video_save_path = os.path.join(os.getcwd(), video_filename)
            video_resp = requests.get(video_url, stream=True)
            video_resp.raise_for_status()
            with open(video_save_path, "wb") as f:
                for chunk in video_resp.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            """

            yield self.create_json_message({
                "video_filename": video_filename,
                "video_url": video_url,
                "video_id": video_id
            })

        except requests.exceptions.RequestException as e:
            yield ToolErrorMessage(err=f"API request failed: {e}")
        except Exception as e:
            yield ToolErrorMessage(err=f"An unexpected error occurred: {e}")
